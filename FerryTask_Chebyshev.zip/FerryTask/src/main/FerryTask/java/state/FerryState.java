package state;

public enum FerryState {
    EMPTY,
    LOADED;
}
